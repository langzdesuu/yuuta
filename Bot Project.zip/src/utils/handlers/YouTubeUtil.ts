import YTI from "youtubei";

const { Client } = YTI;

export const youtube = new Client();
