import i18n from "../../config";

const category = {
    name: i18n.__("commands.music.categoryName"),
    hide: false
};

export default category;
