import i18n from "../../config";

const category = {
    name: i18n.__("commands.moderation.categoryName"),
    hide: false
};

export default category;
